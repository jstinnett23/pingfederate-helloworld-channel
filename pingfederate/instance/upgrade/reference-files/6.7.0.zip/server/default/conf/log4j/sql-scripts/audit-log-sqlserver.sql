# ------------------------------------------------------------
# Create table audit_log
# ------------------------------------------------------------

CREATE TABLE audit_log
(
	id          int NOT NULL IDENTITY (1, 1),
	dtime       datetime NULL,
	event       varchar(255) NULL,
	username    varchar(255) NULL,
	ip          varchar(255) NULL,
	app         varchar(2048) NULL,
	host        varchar(255) NULL,
	protocol    varchar(255) NULL,
	role        varchar(255) NULL,
	partnerid   varchar(255) NULL,
	status      varchar(255) NULL,
	adapterid   varchar(255) NULL,
	description varchar(2048) NULL
)  ON [PRIMARY]
GO

