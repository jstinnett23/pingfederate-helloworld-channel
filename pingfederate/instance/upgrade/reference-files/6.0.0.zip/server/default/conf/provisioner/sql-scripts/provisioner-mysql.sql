# CocoaMySQL dump
# Version 0.7b5
# http://cocoamysql.sourceforge.net
#
# Host: localhost (MySQL 5.0.51a)
# Database: provisioner
# Generation Time: 2008-04-24 17:11:01 -0700
# ************************************************************

# Dump of table channel_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `channel_user`;

CREATE TABLE `channel_user` (
  `channel` int(11) unsigned NOT NULL default '0',
  `dsGuid` varchar(255) NOT NULL default ' ',
  `saasGuid` varchar(255) default NULL,
  `saasUsername` varchar(255) default NULL,
  `valuesHash` varchar(32) default NULL,
  `inGroup` tinyint(1) unsigned NOT NULL default '0',
  `dirty` tinyint(1) unsigned NOT NULL default '1',
  `saasIdentity` text,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`channel`,`dsGuid`),
  UNIQUE KEY `saasGuid` (`channel`,`saasGuid`),
  UNIQUE KEY `saasUsername` (`channel`,`saasUsername`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table channel_variable
# ------------------------------------------------------------

DROP TABLE IF EXISTS `channel_variable`;

CREATE TABLE `channel_variable` (
  `channel` int(11) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`channel`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `node_state`;

CREATE TABLE node_state (
  nodeid    int,
  role      varchar(40) NOT NULL default 'backup',
  heartbeat timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (nodeid)
);
